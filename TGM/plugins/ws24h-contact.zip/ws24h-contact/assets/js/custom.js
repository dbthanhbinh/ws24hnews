function emptyData(data){
    return (!data || data == '' || data == 'undefined') ? true : false;
}

function validateEmail(email) {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}

(function( $ ) {
    var btnAction = 'newsletters-btn-action';
    var errorNote = document.getElementById('newsletters-error');
    var error = 'ffff';

    $('.' + btnAction).on('click', function(){
        var dataField = $(this).attr('data-field');
        var textField = document.getElementsByName(dataField)[0].value;
        if(textField && !emptyData(textField)){
            if(validateEmail(textField)) {
                error = 'Nhập email của bạn!';
                errorNote.className = 'newsletters-error';
                errorNote.innerText = error;
                return false;
            } else {
                error = 'Nhập đúng định dạng email!';
                errorNote.className = 'newsletters-error';
                errorNote.innerText = error;
                return false;    
            }
        } else {
            error = 'Nhập email của bạn!';
            errorNote.className = 'newsletters-error';
            errorNote.innerText = error;
            return false;
        }
    });

} )( jQuery );