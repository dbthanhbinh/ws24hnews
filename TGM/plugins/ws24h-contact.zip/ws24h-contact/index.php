<?php
/**
 * Plugin Name: Ws24h Contact
 * Description: This is my plugin! It makes Contact support
 * Author: leotrinh
 * Version: 1.0
 */

 // Activation #Activation
// To set up an activation hook, use the register_activation_hook() function:
define('PLUGIN_NAME', __("Ws24h Contact"));
define('PLUGIN_DES', __("Description Custom Ws24h Contact Options here"));
define('PLUGIN_PREF', 'ws24h_');
define('PLUGIN_KEYNAME', 'ws24h_Contact_');
define( 'PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
require_once( PLUGIN_DIR . 'newsletters.php' );
require_once( PLUGIN_DIR . 'contact.php' );
require_once( PLUGIN_DIR . 'socials.php' );

register_activation_hook(__FILE__, 'ws24h_contact_activation_hook');
function ws24h_contact_activation_hook(){}

register_deactivation_hook( __FILE__, 'ws24h_contact_deactivation_hook' );
function ws24h_contact_deactivation_hook(){}


function wpb_adding_ws24h_contact() {
   wp_register_style('contact_custom_css', plugins_url( 'assets/css/style.css',    __FILE__ ));
   wp_enqueue_style('contact_custom_css');

   wp_register_script('contact_custom_js', plugins_url( 'assets/js/custom.js', __FILE__ ), array('jquery'),'1.1', true);
   wp_enqueue_script('contact_custom_js');
}
    
add_action( 'wp_enqueue_scripts', 'wpb_adding_ws24h_contact' ); 

add_action( 'widgets_init', function(){
    // register_widget( 'ws24h_contact' );
    register_widget( 'ws24h_contact' );
    register_widget( 'Ws24h_socials' );
});