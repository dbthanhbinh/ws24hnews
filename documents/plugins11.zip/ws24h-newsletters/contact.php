<?php
class Ws24h_contact extends WP_Widget {

	/**
	 * Sets up the widgets name etc
	 */
	public function __construct() {
		$widget_ops = array(
			'classname' => 'ws24h_contact',
			'description' => 'Ws24h contact is awesome',
		);
		parent::__construct( 'ws24h_contact', 'Ws24h contact', $widget_ops );
	}

	/**
	 * Outputs the content of the widget
	 *
	 * @param array $args
	 * @param array $instance
	 */
	public function widget( $args, $instance ) {
		// outputs the content of the widget
		extract( $args );

		$companyName = get_theme_mod('company_name');
		$contactAddress = get_theme_mod('contact_address');
		$contactEmail = get_theme_mod('contact_email');
		$contactPhone = get_theme_mod('contact_phone');

		if($companyName || $contactAddress || $contactEmail || $contactPhone){
			$before_widget = $args['before_widget'];
			echo $before_widget; //$args['before_widget'];
			/*------- Code display front-end ------*/
			?>
			<div class="ws24h-support-group support-contact" rel="nofollow">
				<?php if($companyName){?><h5><?= $companyName ?></h5><?php }?>
				<?php if($contactAddress || $contactEmail || $contactPhone){?>
				<ul class="contact-list">
					<?php if($contactAddress){?><li><i class="fa fa-home" aria-hidden="true"></i> <?= $contactAddress ?></li><?php }?>
					<?php if($contactEmail){?><li><i class="fa fa-envelope-o" aria-hidden="true"></i> <a href="mailto:<?= $contactEmail ?>"> <?= $contactEmail ?></a></li><?php }?>
					<?php if($contactPhone){?><li><i class="fa fa-phone" aria-hidden="true"></i> <a href="tel:<?= $contactPhone ?>"> <?= $contactPhone ?></a></li><?php }?>
				</ul>
				<?php }?>
			</div>
			<?php
			/*------- End Code display front-end ------*/
			echo $args['after_widget'];
		}
	}

	/**
	 * Outputs the options form on admin
	 *
	 * @param array $instance The widget options
	 */
	public function form( $instance ) {
		// outputs the options form on admin
	}

	/**
	 * Processing widget options on save
	 *
	 * @param array $new_instance The new options
	 * @param array $old_instance The previous options
	 */
	public function update( $new_instance, $old_instance ) {
		// processes widget options to be saved
	}
}