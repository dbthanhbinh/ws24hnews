<?php
/**
 * Plugin Name: Ws24h Newsletters
 * Description: This is my plugin! It makes Newsletters support
 * Author: leotrinh
 * Version: 1.0
 */

 // Activation #Activation
// To set up an activation hook, use the register_activation_hook() function:
define('PLUGIN_NAME', __("Ws24h Newsletters"));
define('PLUGIN_DES', __("Description Custom Ws24h Newsletters Options here"));
define('PLUGIN_PREF', 'ws24h_');
define('PLUGIN_KEYNAME', 'ws24h_Newsletters_');
define( 'PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
require_once( PLUGIN_DIR . 'newsletters.php' );
require_once( PLUGIN_DIR . 'contact.php' );
require_once( PLUGIN_DIR . 'socials.php' );

register_activation_hook(__FILE__, 'ws24h_newsletters_activation_hook');
function ws24h_newsletters_activation_hook(){}

register_deactivation_hook( __FILE__, 'ws24h_newsletters_deactivation_hook' );
function ws24h_newsletters_deactivation_hook(){}


function wpb_adding_ws24h_newsletters() {
   wp_register_style('newsletters_custom_css', plugins_url( 'assets/css/style.css',    __FILE__ ));
   wp_enqueue_style('newsletters_custom_css');

   wp_register_script('newsletters_custom_js', plugins_url( 'assets/js/custom.js', __FILE__ ), array('jquery'),'1.1', true);
   wp_enqueue_script('newsletters_custom_js');
}
    
add_action( 'wp_enqueue_scripts', 'wpb_adding_ws24h_newsletters' ); 

add_action( 'widgets_init', function(){
    register_widget( 'ws24h_newsletters' );
    register_widget( 'ws24h_contact' );
    register_widget( 'Ws24h_socials' );
});