<?php
class Ws24h_newsletters extends WP_Widget {

	/**
	 * Sets up the widgets name etc
	 */
	public function __construct() {
		$widget_ops = array(
			'classname' => 'ws24h_newsletters',
			'description' => 'Ws24h newsletters is awesome',
		);
		parent::__construct( 'ws24h_newsletters', 'Ws24h newsletters', $widget_ops );
	}

	/**
	 * Outputs the content of the widget
	 *
	 * @param array $args
	 * @param array $instance
	 */
	public function widget( $args, $instance ) {
		// outputs the content of the widget
		wp_reset_query();
		extract( $args );
		global $wpdb;

		$title = (isset($instance['title']) && $instance['title']) ? $instance['title'] : '';
		$email = (isset($instance['email']) && $instance['email']) ? $instance['email'] : null;
		$description = (isset($instance['description']) && $instance['description']) ? $instance['description'] : null;
		$button_name = (isset($instance['button_name']) && $instance['button_name']) ? $instance['button_name'] : null;

		$before_widget = $args['before_widget'];
        echo $before_widget; //$args['before_widget'];
		/*------- Code display front-end ------*/
		$textField = 'textField';
		$btnActionName = 'newsletters-btn-action';
		?>
		<div class="ws24h-support-group support-newsletters" rel="nofollow">
			<h5><?= $title ?></h5>
			<p><?= $description ?></p>
			<form class="newsletters-form-prev">
				<div class="newsletters-form">
					<input type='email' name='<?= $textField ?>'/>
					<input type='button' class='<?= $btnActionName ?>'
						name='<?= $btnActionName ?>'
						data-field='<?= $textField ?>'
						value='<?= $button_name ?>'/>
				</div>
				<div id="newsletters-error"></div>
			</form>
		</div>
		<?php
        /*------- End Code display front-end ------*/
		echo $args['after_widget'];
		wp_reset_query();
	}

	/**
	 * Outputs the options form on admin
	 *
	 * @param array $instance The widget options
	 */
	public function form( $instance ) {
		// outputs the options form on admin
		$title = (isset($instance['title']) && !empty($instance['title'])) ?  $instance['title'] : __('Đăng ký nhận bản tin');
		$email = (isset($instance['email']) && !empty($instance['email'])) ?  $instance['email'] : '';
		$description = (isset($instance['description']) && !empty($instance['description'])) ? $instance['description'] : __('Để nhận được thông tin dự án mới nhất');
		$button_name = (isset($instance['button_name']) && !empty($instance['button_name'])) ? $instance['button_name'] : 'Đăng ký';
		?>
		<p>
    		<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php echo __( 'Heading:',THEME_NAME ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<p>
    		<label for="<?php echo $this->get_field_id( 'description' ); ?>"><?php echo __( 'description:',THEME_NAME ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'description' ); ?>" name="<?php echo $this->get_field_name( 'description' ); ?>" type="text" value="<?php echo esc_attr( $description ); ?>">
		</p>
		<p>
    		<label for="<?php echo $this->get_field_id( 'email' ); ?>"><?php echo __( 'Email:',THEME_NAME ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'email' ); ?>" name="<?php echo $this->get_field_name( 'email' ); ?>" type="text" value="<?php echo esc_attr( $email ); ?>">
		</p>
		<p>
    		<label for="<?php echo $this->get_field_id( 'button_name' ); ?>"><?php echo __( 'button_name:',THEME_NAME ); ?></label> 
    		<input class="widefat" id="<?php echo $this->get_field_id( 'button_name' ); ?>" name="<?php echo $this->get_field_name( 'button_name' ); ?>" type="text" value="<?php echo esc_attr( $button_name ); ?>">
		</p>

		<?php
	}

	/**
	 * Processing widget options on save
	 *
	 * @param array $new_instance The new options
	 * @param array $old_instance The previous options
	 */
	public function update( $new_instance, $old_instance ) {
		// processes widget options to be saved
		$instance = array();
		$instance['title'] = (isset($new_instance['title']) && !empty($new_instance['title'])) ? strip_tags( $new_instance['title'] ) : '';
		$instance['description'] = (isset($new_instance['description']) && !empty($new_instance['description'])) ? strip_tags( $new_instance['description'] ) : '';
        $instance['email'] = (isset($new_instance['email']) && !empty($new_instance['email'])) ? strip_tags( $new_instance['email'] ) : '';
        $instance['button_name'] = (isset($new_instance['button_name']) && !empty($new_instance['button_name'])) ? strip_tags( $new_instance['button_name'] ) : '';
		return $instance;
	}
}