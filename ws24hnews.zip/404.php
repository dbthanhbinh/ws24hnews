<?php get_header();?>
  <?php require_once ('helpers/layout-configs.php'); ?>
    <div class="row <?= mainLayoutKey() ?>">       
      <div class="container main-content">
        <div class="col-lg-8">
            404 page
        </div>
        <?php get_sidebar();?>
      </div>
    </div>
<?php get_footer();?>