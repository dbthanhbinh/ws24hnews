<?php
const THEMENAME = 'Ws24h-Admin';
const PRICE = 'price';
const DISTRICT = 'district';
const ACREAGE = 'acreage';
const NUMBER_OF_BUILD = 'number-of-build';
const NUMBER_OF_BED = 'number-of-bed';
const NUMBER_OF_BATH = 'number-of-bath';

const LAYOUT_FULL = 'full';
const LAYOUT_LEFT_SIDEBAR = 'left-sidebar';
const LAYOUT_RIGHT_SIDEBAR = 'right-sidebar';