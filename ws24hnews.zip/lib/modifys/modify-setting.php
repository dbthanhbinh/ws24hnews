<?php
require_once ('remove-defaults.php');
require_once ('support.php');