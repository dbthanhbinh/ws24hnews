<?php
$ads_list = [
    [ 'key' => '', 'title' => '' , 'href' => '', 'src' => 'http://saigonbeauty.com.vn/wp-content/uploads/2017/06/lazada.jpeg', 'target' => false ],
    [ 'key' => '', 'title' => '' , 'href' => '', 'src' => 'http://saigonbeauty.com.vn/wp-content/uploads/2017/06/lazada.jpeg', 'target' => false ]
]; 
