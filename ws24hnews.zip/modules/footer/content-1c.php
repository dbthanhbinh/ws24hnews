<div class="row">
    <div class="col-lg-12">
        <?php if (is_active_sidebar( 'footer-1' )) dynamic_sidebar( 'footer-1' );?>
    </div>    
</div>