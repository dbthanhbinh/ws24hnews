<input id="tie_home_cats[<?php echo $i ?>][boxid]" 
    name="tie_home_cats[<?php echo $i ?>][boxid]" 
    value="<?php  echo $boxid; ?>" 
    type="hidden" />

    <input id="tie_home_cats[<?php echo $i ?>][type]" name="tie_home_cats[<?php echo $i ?>][type]" value="<?php  echo $cat['type']  ?>" type="hidden" />
    <a class="del-cat"></a>
</div>